<?php
$conn = new mysqli('localhost', 'root', '', 'test2');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else{

}

$sql = "select id from login where email = '".$_POST['email']."';";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	// var_dump($result);die;
	$row = $result->fetch_assoc();
	// echo $row['id'];die;
	$sql2 = "insert into userlog (uderid, login) values(".$row['id'].", now());";

	if ($conn->query($sql2) === TRUE) {
		 $last_id = $conn->insert_id;
		 // echo $last_id;die;
    require('main.html');
} else {
    echo "Error: " . $sql2 . "<br>" . $conn->error;
}



}
else{
	echo 'Error in first';
}
$conn->close();
?>
