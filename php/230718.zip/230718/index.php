<?php
require_once('config.php');
require_once('./includes/header.php');?>
<header>
<?php require_once('./includes/nav.php'); ?>
</header>
<?php require_once('./includes/footer.php');


?>

                
  