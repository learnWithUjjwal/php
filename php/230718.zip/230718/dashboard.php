<?php
require_once('./config.php');
require_once('./db.php');
require_once('./includes/header.php');
require_once('./includes/nav.php');
?>

<div>
    Welcome to DashBoard
</div>


