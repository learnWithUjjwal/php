<?php
session_start();

//DB configurations
define('SERVER_NAME', 'localhost');
define('DB_NAME', 'student');
define('USERNAME', 'root');
define('PASSWORD', '');
